// Load the data
const iris = d3.csv("iris.csv");

// Once the data is loaded, proceed with plotting
d3.csv("iris.csv").then(function(data) {
    // Convert string values to numbers
    data.forEach(function(d) {
        d.PetalLength = +d.PetalLength;
        d.PetalWidth = +d.PetalWidth;
    });

    // Define the dimensions and margins for the SVG
    const margin = {top: 30, right: 30, bottom: 60, left: 60},
          width = 600 - margin.left - margin.right,
          height = 400 - margin.top - margin.bottom;
    

    // Create the SVG container
    const svg = d3.select('#scatterplot')
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);
    
    // Set up scales for x and y axes
    const xScale = d3.scaleLinear()
        .domain([d3.min(data, d => d.PetalLength) - 0.5, d3.max(data, d => d.PetalLength) + 0.5])
        .range([0, width]);
    
    const yScale = d3.scaleLinear()
        .domain([d3.min(data, d => d.PetalWidth) - 0.5, d3.max(data, d => d.PetalWidth) + 0.5])
        .range([height, 0]);

    // d3.min(data, d => d.bill_length_mm)-5

    const colorScale = d3.scaleOrdinal()
        .domain(data.map(d => d.Species))
        .range(d3.schemeCategory10);

    // Add scales     
    // Add x-axis
    svg.append("g")
       .attr("transform", `translate(0, ${height})`) // Move to the bottom of the SVG
       .call(d3.axisBottom(xScale));

    // Add y-axis
    svg.append("g")
       .call(d3.axisLeft(yScale));

    // Add circles for each data point
    svg.selectAll("circle")
       .data(data)
       .enter()
       .append("circle")
       .attr("cx", d => xScale(d.PetalLength))
       .attr("cy", d => yScale(d.PetalWidth))
       .attr("r", 5)
       .style("fill", d => colorScale(d.Species))
       .style("opacity", 0.7);

    // Add x-axis label
    svg.append("text")
       .attr("x", width / 2)
       .attr("y", height + 40) // Position it below the x-axis
       .attr("text-anchor", "middle")
       .attr("fill", "black")
       .text("Petal Length");

    // Add y-axis label
    svg.append("text")
       .attr("x", -height / 2) // Position it in the middle of the y-axis
       .attr("y", -40) // Move it to the left of the y-axis
       .attr("transform", "rotate(-90)") // Rotate the label vertically
       .attr("text-anchor", "middle")
       .attr("fill", "black")
       .text("Petal Width");

    // Add legend
    const legend = svg.selectAll(".legend")
        .data(colorScale.domain())
        .enter().append("g")
        .attr("class", "legend")
        .attr("transform", (d, i) => "translate(0," + i * 20 + ")");
    
    legend.append("rect")
        .attr("x", width - 18)
        .attr("width", 18)
        .attr("height", 18)
        .style("fill", colorScale);
    
    legend.append("text")
        .attr("x", width - 24)
        .attr("y", 9)
        .attr("dy", ".35em")
        .style("text-anchor", "end")
        .text(d => d);
});

d3.csv("iris.csv").then(function(data) {
    // Convert string values to numbers
    data.forEach(function(d) {
        d.PetalLength = +d.PetalLength;
        d.PetalWidth = +d.PetalWidth;
    });
    

    // Define the dimensions and margins for the SVG
    const margin = { top: 30, right: 30, bottom: 60, left: 60 },
          width = 600 - margin.left - margin.right,
          height = 400 - margin.top - margin.bottom;


    // Create the SVG container
    const svg = d3.select("#boxplot")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);


    // Set up scales for x and y axes
    const xScale = d3.scaleBand()
        .domain(data.map(d => d.Species)) // Set domain as species names
        .range([0, width])
        .padding(0.2);

    const yScale = d3.scaleLinear()
        .domain([d3.min(data, d => d.PetalLength) - 0.5, d3.max(data, d => d.PetalLength) + 0.5])
        .range([height, 0]);


    // Add scales     
    svg.append("g")
       .attr("transform", `translate(0, ${height})`)
       .call(d3.axisBottom(xScale));

    svg.append("g")
       .call(d3.axisLeft(yScale));


    // Add x-axis label
    svg.append("text")
        .attr("x", width / 2)
        .attr("y", height + 50)
        .attr("text-anchor", "middle")
        .text("Species");


    // Add y-axis label
    

    const rollupFunction = function(groupData) {
        const values = groupData.map(d => d.PetalLength).sort(d3.ascending);
        const q1 = d3.quantile(values, 0.25);
        const median = d3.quantile(values, 0.5);
        const q3 = d3.quantile(values, 0.75);
        return { q1, median, q3};
    };

    const quartilesBySpecies = d3.rollup(data, rollupFunction, d => d.Species);

    quartilesBySpecies.forEach((quartiles, Species) => {
        const x = xScale(Species);
        const boxWidth = xScale.bandwidth();

        // Draw vertical lines
        svg.append("line")
           .attr("x1", x + boxWidth / 2)
           .attr("x2", x + boxWidth / 2)
           .attr("y1", yScale(quartiles.q1))
           .attr("y2", yScale(quartiles.q3))
           .attr("stroke", "black");

        // Draw box
        svg.append("rect")
           .attr("x", x)
           .attr("y", yScale(quartiles.q3))
           .attr("width", boxWidth)
           .attr("height", yScale(quartiles.q1) - yScale(quartiles.q3))
           .attr("fill", "lightblue")
           .attr("stroke", "black");

        // Draw median line
        svg.append("line")
           .attr("x1", x)
           .attr("x2", x + boxWidth)
           .attr("y1", yScale(quartiles.median))
           .attr("y2", yScale(quartiles.median))
           .attr("stroke", "black");
        
    });

});